﻿namespace DeckManager
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            RegisterRoutes();
        }

        private void RegisterRoutes()
        {
            Routing.RegisterRoute(nameof(ApprentissagePage), typeof(ApprentissagePage));
            Routing.RegisterRoute(nameof(GestionPage), typeof(GestionPage));
            Routing.RegisterRoute(nameof(ResumePage), typeof(ResumePage));
            Routing.RegisterRoute("DeckDetails", typeof(DeckDetails));
        }
    }
}
