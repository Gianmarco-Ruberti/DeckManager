using DeckManager.Models;
using DeckManager.ViewModels;

namespace DeckManager;

public partial class DeckDetails : ContentPage
{
    private GestionViewModel _viewModel;

    public DeckDetails()
    {
        InitializeComponent();
        _viewModel = new GestionViewModel();
        BindingContext = _viewModel;
    }

    private async void OnAddFlashcardClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(GestionPage));
    }

    private async void OnStartLearningClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(ApprentissagePage));
    }

    private async void OnEditFlashcard(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(GestionPage));
    }

    private void OnDeleteFlashcard(object sender, EventArgs e)
    {
        if (sender is Button button && button.CommandParameter is FlashcardModel flashcard)
        {
            _viewModel.DeleteFlashcard(flashcard);
        }
    }
}
