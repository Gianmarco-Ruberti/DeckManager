using DeckManager.ViewModels;

namespace DeckManager;

public partial class ApprentissagePage : ContentPage
{
    private ApprentissageViewModel _viewModel;

    public ApprentissagePage()
    {
        InitializeComponent();
        _viewModel = new ApprentissageViewModel();
        BindingContext = _viewModel;
    }

    private async void OnCloseClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("..");
    }

    private void OnFailedClicked(object sender, EventArgs e)
    {
        _viewModel.MarkAsFailed();
    }

    private void OnSuccessClicked(object sender, EventArgs e)
    {
        _viewModel.MarkAsSuccess();
    }
}
