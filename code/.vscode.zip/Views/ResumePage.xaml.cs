namespace DeckManager;

public partial class ResumePage : ContentPage
{
    public ResumePage()
    {
        InitializeComponent();
    }

    private async void OnBackHomeClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(DeckDetails));
    }
}
