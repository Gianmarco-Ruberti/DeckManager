using DeckManager.ViewModels;

namespace DeckManager;

public partial class GestionPage : ContentPage
{
    private GestionViewModel _viewModel;

    public GestionPage()
    {
        InitializeComponent();
        _viewModel = new GestionViewModel();
        BindingContext = _viewModel;
    }

    private async void OnCancelClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("..");
    }

    private async void OnSaveClicked(object sender, EventArgs e)
    {
        _viewModel.SaveFlashcard();
        await Shell.Current.GoToAsync("..");
    }
}
