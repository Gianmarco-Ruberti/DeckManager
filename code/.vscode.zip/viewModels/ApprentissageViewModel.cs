using System.Collections.ObjectModel;
using System.Windows.Input;
using DeckManager.Models;

namespace DeckManager.ViewModels;

public class ApprentissageViewModel : BindableObject
{
    private ObservableCollection<FlashcardModel> flashcards;
    private FlashcardModel currentFlashcard;
    private int currentIndex = 0;
    private double progress = 0;
    private DateTime startTime;

    public ObservableCollection<FlashcardModel> Flashcards
    {
        get => flashcards;
        set
        {
            flashcards = value;
            OnPropertyChanged();
        }
    }

    public FlashcardModel CurrentFlashcard
    {
        get => currentFlashcard;
        set
        {
            currentFlashcard = value;
            OnPropertyChanged();
        }
    }

    public double Progress
    {
        get => progress;
        set
        {
            progress = value;
            OnPropertyChanged();
        }
    }

    public ApprentissageViewModel()
    {
        flashcards = new ObservableCollection<FlashcardModel>();
        startTime = DateTime.Now;
        LoadFlashcards();
    }

    private void LoadFlashcards()
    {
        // TODO: Charger les flashcards depuis la base de données
        CurrentFlashcard = flashcards.Count > 0 ? flashcards[0] : new FlashcardModel();
    }

    public void MarkAsSuccess()
    {
        if (CurrentFlashcard != null)
        {
            CurrentFlashcard.SuccessCount++;
        }
        NextFlashcard();
    }

    public void MarkAsFailed()
    {
        if (CurrentFlashcard != null)
        {
            CurrentFlashcard.FailureCount++;
        }
        NextFlashcard();
    }

    private void NextFlashcard()
    {
        if (currentIndex < flashcards.Count - 1)
        {
            currentIndex++;
            CurrentFlashcard = flashcards[currentIndex];
            Progress = (double)currentIndex / flashcards.Count;
        }
        else
        {
            // Session terminée, naviguer vers le résumé
            Shell.Current.GoToAsync("resume");
        }
    }
}
