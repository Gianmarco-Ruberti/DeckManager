using System.Collections.ObjectModel;
using DeckManager.Models;

namespace DeckManager.ViewModels;

public class GestionViewModel : BindableObject
{
    private FlashcardModel currentFlashcard;
    private ObservableCollection<FlashcardModel> flashcards;

    public FlashcardModel CurrentFlashcard
    {
        get => currentFlashcard;
        set
        {
            currentFlashcard = value;
            OnPropertyChanged();
        }
    }

    public ObservableCollection<FlashcardModel> Flashcards
    {
        get => flashcards;
        set
        {
            flashcards = value;
            OnPropertyChanged();
        }
    }

    public GestionViewModel()
    {
        currentFlashcard = new FlashcardModel();
        flashcards = new ObservableCollection<FlashcardModel>();
        LoadFlashcards();
    }

    private void LoadFlashcards()
    {
        // TODO: Charger les flashcards depuis la base de données
    }

    public void SaveFlashcard()
    {
        if (string.IsNullOrWhiteSpace(CurrentFlashcard.Question) || 
            string.IsNullOrWhiteSpace(CurrentFlashcard.Answer))
        {
            MainThread.BeginInvokeOnMainThread(async () =>
            {
                await Shell.Current.DisplayAlert("Erreur", "Veuillez remplir tous les champs", "OK");
            });
            return;
        }

        // TODO: Sauvegarder dans la base de données
        flashcards.Add(CurrentFlashcard);
        CurrentFlashcard = new FlashcardModel();
    }

    public void DeleteFlashcard(FlashcardModel flashcard)
    {
        if (flashcard != null && flashcards.Contains(flashcard))
        {
            flashcards.Remove(flashcard);
            // TODO: Supprimer de la base de données
        }
    }
}
