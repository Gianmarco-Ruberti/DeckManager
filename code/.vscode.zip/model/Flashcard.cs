namespace DeckManager.Models;

public class FlashcardModel
{
    public int Id { get; set; }
    public string Question { get; set; } = string.Empty;
    public string Answer { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public int SuccessCount { get; set; } = 0;
    public int FailureCount { get; set; } = 0;
}
